Crash Extract was Generated on the Following Criteria:
-------------------------------------------------------

Generated on 6/8/2017 8:35:34 PM

Extract Type : County
From Date    : 06/01/2015
To Date      : 12/31/2015
Report Type  : Full Extract
Report Format: Text File
County       : Stark County
Total records: 5116
