Crash Extract was Generated on the Following Criteria:
-------------------------------------------------------

Generated on 6/8/2017 8:37:08 PM

Extract Type : County
From Date    : 01/01/2017
To Date      : 06/01/2017
Report Type  : Full Extract
Report Format: Text File
County       : Stark County
Total records: 3793
