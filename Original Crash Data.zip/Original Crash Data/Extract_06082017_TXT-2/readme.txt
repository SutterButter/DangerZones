Crash Extract was Generated on the Following Criteria:
-------------------------------------------------------

Generated on 6/8/2017 8:36:25 PM

Extract Type : County
From Date    : 01/01/2016
To Date      : 12/31/2016
Report Type  : Full Extract
Report Format: Text File
County       : Stark County
Total records: 9264
